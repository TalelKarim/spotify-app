def main(event, context):
    return {"status": "ok"}
